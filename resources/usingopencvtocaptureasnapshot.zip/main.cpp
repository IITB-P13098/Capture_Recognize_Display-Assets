// main.c : Defines the entry point for the console application.
//
//#pragma comment(lib, "OCRToyDLL")
#include <stdio.h>
//#include <stdafx>
#include <cv.h>
#include "cxcore.h"
#include "highgui.h"
#include "cxtypes.h"
#include "Toy.h"
#include <windows.h>
#include <stdlib.h>
///#include <wchar.h>

int getDLL(IplImage *frame,g_Resolution camRes,g_Resolution scrRes);
//extern "C" int __cdecl fn_CaliberateCamera(IplImage *frame,g_Resolution camRes,g_Resolution scrRes);

int main(int argc, CHAR* argv[])
{

    //----Calibrate the camera / screen
    //IplImage *image = cvLoadImage("page1.jpg");//This image needs to be shown on the LCD screen
	IplImage *image = cvLoadImage("fourCorners.bmp");
	cvNamedWindow( "mywindow", CV_WINDOW_AUTOSIZE );
	cvShowImage("mywindow",image);

	CvCapture* capture = cvCaptureFromCAM(0);
	if ( !capture ) {
		fprintf( stderr, "ERROR: capture is NULL \n" );
		getchar();
		return -1;
	}

	IplImage *curr_frame = cvQueryFrame(capture);

	//--Calibrate
	g_Resolution screenResolution;
	screenResolution.width = 1024; //width of the screen
	screenResolution.height = 600; //height of the screen
	g_Resolution cameraResolution;
	cameraResolution.width = curr_frame->width;//width of the camera
	cameraResolution.height = curr_frame->height;//height of the camera
	wchar_t buff[1024];
	char buff2[1024];

	int calibrationFlag = fn_CaliberateCamera(curr_frame,cameraResolution,screenResolution);
	if(calibrationFlag==1)
		OutputDebugString("caliberation done\n");
	else{
		OutputDebugString("caliberation failed\n");
		return 0;
	}

	//--Init engine
	fn_InitEngine();
	OutputDebugString("Engine initialised successfully...\n");
	
	//g_OCRCharInfo *temp= new g_OCRCharInfo();
	//temp->g_UnicodeChars[0]= wchar_t(0x0915);
	//std::wcout << L (temp->g_UnicodeChars[0]) << std::endl;
	//sprintf("%",temp->g_UnicodeChars[0]);
	//OutputDebugString((LPCSTR)0x0915);
	//OutputDebugString(temp->g_UnicodeChars[0]);

	int counter=0,number=0,recog=0;
	g_OCRCharInfo *g_Output=(g_OCRCharInfo *)malloc(sizeof(g_OCRCharInfo));
	if(g_Output==NULL)
		OutputDebugString("Mem allocation problem");

	while ( 1 ) {
	// Get one frame
	counter++;
	 curr_frame = cvQueryFrame( capture );
	if ( !curr_frame ) {
	fprintf( stderr, "ERROR: frame is null...\n" );
	getchar();
	break;
	}
	cvShowImage( "mywindow", curr_frame );
	//cvSaveImage("frame##.png",);
	// Do not release the frame!
	//If ESC key pressed, Key=0x10001B under OpenCV 0.9.7(linux version),
	//remove higher bits using AND operator
	if(counter>500){
		//sprintf(filename,"frame%u.jpg",number);
		//cvSaveImage(filename,frame,0);
		OutputDebugString("counter>10\n");
		 //g_Output= fn_RecognizeChars(curr_frame,0); //0 for chars, 1 for numerals 
		recog= fn_RecognizeChars(curr_frame,0,&g_Output); //0 for chars, 1 for numerals 
		//sprintf(buff2,"now: %c %d %x ",g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[0]);
		
		 //sprintf(buff2,"now: 1:%x 2:%x 3:%x 4:%x 5:%x 6:%x ",g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[1],g_Output->g_UnicodeChars[2],g_Output->g_UnicodeChars[3],g_Output->g_UnicodeChars[4],g_Output->g_UnicodeChars[5]);
		
		sprintf(buff2,"Test:chars recog count %d",recog);
		OutputDebugString(buff2);
		//for(int i=0;i<APP_MAX_SHAPES;i++){
		for(int i=0;i<recog;i++){
			//sprintf(buff2,"\nNow: Angle:%f Char:%x Bounded by:(%d,%d)(%d,%d) with centroid at(%d,%d) ",g_Output->g_Angle[i],g_Output->g_UnicodeChars[i],g_Output->boundingBoxes->minX,g_Output->boundingBoxes->minY,g_Output->boundingBoxes->maxX,g_Output->boundingBoxes->maxY,g_Output->centroids->x,g_Output->centroids->y);
			sprintf(buff2,"\nTest: Angle:%f Char:%x Bounded by:(%d,%d)(%d,%d) with centroid at(%d,%d) ",g_Output->g_Angle[i],g_Output->g_UnicodeChars[i],(g_Output->boundingBoxes[i]).minX,(g_Output->boundingBoxes[i]).minY,(g_Output->boundingBoxes[i]).maxX,(g_Output->boundingBoxes[i]).maxY,(g_Output->centroids[i]).x,(g_Output->centroids[i]).y);
			OutputDebugString(buff2);
		}
		//swprintf(buff,1024,"%s",g_Output->g_UnicodeChars);
		//swprintf(buff,1024,L"%c %x",g_Output->g_UnicodeChars[0]);
		//OutputDebugString((LPCSTR)g_Output->g_UnicodeChars[0]);

		//OutputDebugString(buff2);
		
		break;//counter=0;
	}else{
		OutputDebugString("counter<10\n");
		//g_Output = fn_RecognizeChars(curr_frame,0); //0 for chars, 1 for numerals 
		recog= fn_RecognizeChars(curr_frame,0,&g_Output); //0 for chars, 1 for numerals 
		//sprintf(buff2,"test: %c %d %x ",g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[0]);
		
		//sprintf(buff2,"test: 1:%x 2:%x 3:%x 4:%x 5:%x 6:%x ",g_Output->g_UnicodeChars[0],g_Output->g_UnicodeChars[1],g_Output->g_UnicodeChars[2],g_Output->g_UnicodeChars[3],g_Output->g_UnicodeChars[4],g_Output->g_UnicodeChars[5]);
		//OutputDebugString((LPCSTR)g_Output->g_UnicodeChars[0]);
		//OutputDebugString(buff2);

		sprintf(buff2,"Test:chars recog count %d",recog);
		OutputDebugString(buff2);
		//for(int i=0;i<APP_MAX_SHAPES;i++){
		for(int i=0;i<recog;i++){
			sprintf(buff2,"\nTest: Angle:%f Char:%x Bounded by:(%d,%d)(%d,%d) with centroid at(%d,%d) ",g_Output->g_Angle[i],g_Output->g_UnicodeChars[i],(g_Output->boundingBoxes[i]).minX,(g_Output->boundingBoxes[i]).minY,(g_Output->boundingBoxes[i]).maxX,(g_Output->boundingBoxes[i]).maxY,(g_Output->centroids[i]).x,(g_Output->centroids[i]).y);
			OutputDebugString(buff2);
		}

	}

	if ((cvWaitKey(10) & 255) == 27) break;
	number++;
	}
	//OutputDebugString("Calling DLL \n");
	//getDLL(curr_frame,cameraResolution,screenResolution);
	//OutputDebugString("Done calling DLL \n");

	//if ((cvWaitKey(10) & 255) == 27)
		//OutputDebugString("Wait...\n");
	//cleanup
	cvDestroyWindow( "mywindow" );
	cvReleaseCapture( &capture );
	
	fn_FreeEngine();
	OutputDebugString("Engine freed successfully...\n");

	return 0;
}

int getDLL(IplImage *frame,g_Resolution camRes,g_Resolution scrRes){
	typedef int (__cdecl *MYPROC)(LPWSTR); 
	HANDLE ProcCalib;

	// 1. Load the library
	OutputDebugString("Running LoadLibrary \n");
  	HMODULE hMod = LoadLibrary ("OCRToyDLL.dll");
	OutputDebugString("LoadLibrary run\n");
   	
	if (NULL == hMod)
   	{
  		printf ("LoadLibrary failed\n");
		OutputDebugString("LoadLibrary failed\n");
  		return 1;
   	}
	
	//PCTOR pCtor = (PCTOR) GetProcAddress (hMod, "fn_CaliberateCamera");
	ProcCalib=(MYPROC)GetProcAddress (hMod, "fn_CaliberateCamera");
	if (NULL == ProcCalib)
   	{
 		printf ("GetProcAddress Ctor failed\n");
		OutputDebugString("GetProcAddress Ctor failed\n");
   		return 1;
 	}
	
	FreeLibrary (hMod);

	return 0;

}
