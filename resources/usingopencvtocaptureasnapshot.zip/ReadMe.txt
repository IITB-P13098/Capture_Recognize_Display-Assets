Changes: v1.0.0.3

Hi Manjiri,

All issues mentioned by you have been solved.

Regarding first query,the question of thread safety arises if we develop code in the multithreaded evniroment. But since,we haven't use multithreading in our code,the functions in the DLL are not thread safe.

Regarding second query,The bug is resolved. The characters are recognized in the order of red,yellow,green and blue.For example If  blue character is placed first,then recognized blue character will be present at index 0 in  g_OCRCharInfo array. And after some time if a red character is placed without removing the blue character, then recognized red character will be at  index 0 and blue character at index 1 in that array..

For knowing the no of recognized characters, we have changed the API fn_RecognizeChars() .

int fn_RecognizeChars(IplImage* inputImage,int fAlphaNumeral,g_OCRCharInfo** g_OutputCharInfo)

Input parameters
1.inputImage [in] The camera captured frame
2.fAlphaNumeral [in] Flag stating if character to be recognized is alphabets or numerals
3. g_OutputCharInfo [inout] Allocated structure is send to the function and gets filled with recognized characters.

Return parameter
1.No of recognized characters

I have attached a new DLL with the above mentioned changes.Please change the extension from .dat to .dll

Issues:
Hi Swapnil,

I had a couple of queries regarding the functions in the DLL :
1. Are the functions in the DLL thread-safe?
2. The  g_OCRCharInfo struct returned by fn_RecognizeChars() doesnt seem to be re-populated for each call made to fn_RecognizeChars(), so the actual recognised char could be at position 0 during first call and at position 3 during the next. unless the remaining array members are empty / null no way to determine how many chars actually found in the current snapshot.

_____


Follow the given instructions:

1)Extract all the files in the same folder as the exe.

2)For calibration,use 'fourCorners.bmp' image which is placed in same folder as dll.
	
	for eg:
	IplImage *image = cvLoadImage("fourCorners.bmp");//This image needs to be shown on the LCD screen
	CvCapture capture = cvCaptureFromCAM(CV_CAP_ANY);
	IplImage *curr_frame = cvQueryFrame(capture);
	g_Resolution screenResolution;
	screenResolution.width = //width of the screen
	screenResolution.height = //height of the screen
	g_Resolution cameraResolution;
	cameraResolution.width = curr_frame->width;//width of the camera
	cameraResolution.height = curr_frame->height;//height of the camera
	
	int calibrationFlag = fn_CaliberateCamera(curr_frame,cameraResolution,screenResolution).
	

3)fn_InitEngine() should be called after fn_CaliberateCamera().

4)Input Image to the fn_RecognizeChars should not be preprocessed.

	for eg:
	CvCapture capture = cvCaptureFromCAM(CV_CAP_ANY);
	IplImage *curr_frame = cvQueryFrame(capture);
	g_OCRCharInfo *g_Output = fn_RecognizeChars(curr_frame,0);
	
5)While exiting the toy game, call fn_FreeEngine() to free all the resources used by the dll.

6)Currently angle is zero.