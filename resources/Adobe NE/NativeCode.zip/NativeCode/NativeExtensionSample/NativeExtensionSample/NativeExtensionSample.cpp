#include "FlashRuntimeExtensions.h"
#include <stdio.h>
#include <malloc.h>
#include <iostream>
#include "NativeExtensionSample.h"
using namespace std;



FREObject nativeHello(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
	
	FREObject fo;
	const char *str = "This string is being sent from ANE side";
	FRENewObjectFromUTF8(strlen(str),(const uint8_t *)str, &fo); // str will be sent from native side
	FREDispatchStatusEventAsync(ctx,(const uint8_t *)"doneFromNative", (const uint8_t *)"status"); //dispatching event from native side
	return fo;
}

void ContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx,
                                                uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
        *numFunctionsToTest = 1;
        FRENamedFunction* func = (FRENamedFunction*)malloc(sizeof(FRENamedFunction)*(*numFunctionsToTest));
        func[0].name = (const uint8_t*)"nativeHello";
		func[0].functionData = NULL;
        func[0].function = &nativeHello;

        *functionsToSet = func;


}

void ContextFinalizer(FREContext ctx) {
        printf("inside ContextFinalizer method ");
        return;
}

void ExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet,
                                        FREContextFinalizer* ctxFinalizerToSet) {
        printf("inside extension initializer method");
        *extDataToSet = NULL;
        *ctxInitializerToSet = &ContextInitializer;
        *ctxFinalizerToSet = &ContextFinalizer;
}

void ExtFinalizer(void* extData) {
        printf("inside extension finalizer method");
        return;
}
