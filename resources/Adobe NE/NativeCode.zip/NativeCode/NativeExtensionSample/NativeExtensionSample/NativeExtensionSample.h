#include "FlashRuntimeExtensions.h"

 
extern "C" __declspec(dllexport) void ExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet);
extern "C" __declspec(dllexport) void ExtFinalizer(void* extData);
extern "C" __declspec(dllexport) FREObject nativeHello(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);


